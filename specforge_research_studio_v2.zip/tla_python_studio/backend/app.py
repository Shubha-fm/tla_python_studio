import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from tla_parser import tla_to_python_from_string, TranslationError
from verification import verify

ROOT=os.path.dirname(os.path.abspath(__file__))
FRONTEND=os.path.join(ROOT,'..','frontend','build')
app=Flask(__name__,static_folder=FRONTEND,static_url_path='/')
CORS(app,origins=os.environ.get('CORS_ORIGINS','http://localhost:3000').split(','))
app.config['MAX_CONTENT_LENGTH']=250_000

@app.get('/api/health')
def health():return jsonify(ok=True,service='TLA+ Python Studio',version='1.0')

@app.post('/api/convert')
def convert():
    data=request.get_json(silent=True)
    if not isinstance(data,dict):return jsonify(ok=False,error='Provide a JSON object.'),400
    if data.get('mode','tla')!='tla':return jsonify(ok=False,error='Lean conversion is not available: the original implementation was a placeholder.'),422
    try:return jsonify(ok=True,output=tla_to_python_from_string(data.get('code','')),warnings=['Restricted TLA+ subset only. Generated Python is not a refinement proof or a replacement for TLC.'])
    except (TranslationError,ValueError) as e:return jsonify(ok=False,error=str(e)),422

@app.post('/api/verify')
def verification():
    data=request.get_json(silent=True)
    if not isinstance(data,dict):return jsonify(ok=False,error='Provide a JSON object.'),400
    try:
        result=verify(data.get('code',''), data.get('property',''),data.get('max_depth',12),data.get('max_states',120))
        return jsonify(ok=True,**result)
    except (TranslationError,ValueError,SyntaxError,TypeError) as e:
        return jsonify(ok=False,error=str(e)),422

@app.get('/')
def index():return send_from_directory(FRONTEND,'index.html')

@app.get('/<path:path>')
def static_files(path):
    if path.startswith('api/'):return jsonify(error='Not found'),404
    file=os.path.join(FRONTEND,path)
    return send_from_directory(FRONTEND,path if os.path.isfile(file) else 'index.html')

if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.environ.get('PORT','5050')),debug=os.environ.get('FLASK_DEBUG')=='1')

import unittest
from tla_parser import tla_to_python_from_string, TranslationError
SAMPLE=r'''---- MODULE Counter ----
EXTENDS Naturals
VARIABLES count
Init == count = 0
Increment == /\ count < 3
             /\ count' = count + 1
Reset == /\ count >= 3
         /\ count' = 0
Next == \/ Increment
        \/ Reset
===='''
class ConverterTest(unittest.TestCase):
 def test_counter(self):
  code=tla_to_python_from_string(SAMPLE)
  env={'__name__':'test'}
  exec(compile(code,'generated.py','exec'),env)
  s=env['INITIAL_STATE']
  self.assertEqual([x['count'] for x in env['next_states'](s)],[1])
  self.assertEqual([x['count'] for x in env['next_states']({'count':3})],[0])
 def test_reject_unsupported(self):
  with self.assertRaises(TranslationError):tla_to_python_from_string('VARIABLES x\nInit == x = 0\nNext == UNCHANGED x')
if __name__=='__main__':unittest.main()

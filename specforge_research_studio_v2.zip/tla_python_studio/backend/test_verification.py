import unittest
from verification import verify
SOURCE="""---- MODULE Counter ----
VARIABLES count
Init == count = 0
Increase == /\\ count < 3
            /\\ count' = count + 1
Reset == /\\ count >= 3
         /\\ count' = 0
Next == \\/ Increase
        \\/ Reset
===="""
class VerificationTests(unittest.TestCase):
    def test_graph_and_valid_property(self):
        result=verify(SOURCE,'count >= 0')
        self.assertEqual(result['summary']['states'],4)
        self.assertEqual(result['summary']['transitions'],4)
        self.assertEqual(result['summary']['property_status'],'pass_finite_graph')
    def test_violation_with_trace(self):
        result=verify(SOURCE,'count < 2')
        self.assertEqual(result['summary']['property_status'],'violation')
        self.assertEqual(result['counterexample'],[0,1,2])
    def test_bound_is_not_proof(self):
        result=verify(SOURCE,'count >= 0',max_depth=1)
        self.assertTrue(result['summary']['truncated'])
        self.assertEqual(result['summary']['property_status'],'bounded_pass')
if __name__=='__main__':unittest.main()

# SpecForge: TLA+ to Python Studio

A React and Flask web app for converting a **restricted, explicit subset** of TLA+ state-transition specifications to executable Python. Derived from the uploaded prototype; frontend and conversion engine have been replaced/updated.

## Run locally

Requires Python 3.10+ and Node.js 18+.

```bash
cd backend
python -m pip install -r requirements.txt
python app.py
```

In a second terminal:

```bash
cd frontend
npm ci
npm start
```

Open http://localhost:3000. The development frontend needs the backend URL. Create `frontend/.env` containing `REACT_APP_API_BASE=http://localhost:5050` before starting React.

## Single-server production mode

```bash
cd frontend && npm ci && npm run build
cd ../backend && pip install -r requirements.txt
waitress-serve --host=0.0.0.0 --port=5050 app:app
```

Open http://localhost:5050. Deploy with `render.yaml` on Render or an equivalent platform.

## Supported subset

- `VARIABLES x, y`
- `Init == /\\ x = 0 /\\ y = TRUE` with one integer/boolean literal per variable
- `Next == Increment \\/ Reset` naming existing action definitions, or an inline conjunctive action
- Guards using integer literals, declared variables, arithmetic `+`, `-`, `*`, parentheses and comparisons `=`, `/=`, `<`, `>`, `<=`, `>=`
- Conjunctive action assignments such as ` /\\ x' = x + 1`
- Every action must assign **every** state variable; this avoids silently assuming frame conditions.

The output includes `INITIAL_STATE`, `next_states(state)` (a nondeterministic successor relation), and a bounded example `explore()` routine. It does **not** claim to preserve complete TLA+ semantics. Unsupported syntax results in an explicit validation error. Lean mode has been removed because the original returned a stub unrelated to the source.

**Not supported:** modules as operators, quantifiers, sets, tuples, records, functions, `UNCHANGED`, sequential composition, nested operator calls, fairness, TLC semantics, temporal properties, and full TLA+ expression syntax. The Python code is not a formal proof of correctness and must not be mistaken for verification of the source model.

## API

`POST /api/convert` with JSON `{"code":"...","mode":"tla"}`. Success: `{"ok":true,"output":"...","warnings":[...]}`. Error: HTTP 422 with `{"ok":false,"error":"..."}`. `GET /api/health` for readiness checks.

## Security

Generated Python is returned as text and is **not run on the server**. No model files are retained by the API. Do not execute Python generated from untrusted sources without review.

## State graph and property checks (research explorer)

Open **State explorer**, set a state property such as `count >= 0`, optionally adjust exploration depth (0–40) and maximum states (1–500), then select **Run checks**. The application constructs a bounded explicit-state graph, reports distinct reachable states, directed transitions, deadlocks and the first violation, and displays a shortest-discovery predecessor trace. Click a node to inspect its state.

The `/api/verify` POST endpoint accepts `{"code":"...", "property":"count >= 0", "max_depth":12, "max_states":120}`. The result includes `nodes`, `edges`, `summary`, `counterexample`, and `deadlock_trace`. The property is a single-state expression using the converter's supported integer/boolean expression subset; it is **not** a TLA+ temporal formula. The graph exploration is **not TLC** and bounded success does **not prove** correctness of an unbounded model. `pass_finite_graph` means exploration exhausted reachable states without encountering a depth/state limit, **under the converter's restricted semantics**. TLC integration remains future work and is not advertised as present.
